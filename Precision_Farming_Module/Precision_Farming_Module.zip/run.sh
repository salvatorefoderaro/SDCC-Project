clear
python3 app.py